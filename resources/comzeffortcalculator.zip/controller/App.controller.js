sap.ui.define(["./BaseController"],function(n){"use strict";return n.extend("com.zeffortcalculator.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map