sap.ui.define(
    [
      "./BaseController",
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.zeffortcalculator.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  